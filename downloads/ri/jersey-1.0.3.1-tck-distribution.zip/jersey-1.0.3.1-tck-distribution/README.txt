Thie directory contains the two jars, jersey-core-1.0.3.1.jar and jersey-server-1.0.3.1.jar, that are utilized by the TCK.

For documentaton please refer to:

https://jersey.dev.java.net/source/browse/*checkout*/jersey/tags/jersey-1.0.3.1/jersey/dependencies.html
